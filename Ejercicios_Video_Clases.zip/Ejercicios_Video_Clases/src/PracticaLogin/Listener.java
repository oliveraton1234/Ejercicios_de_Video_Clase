package PracticaLogin;

public interface Listener {
    public void mirarContraseña();
    public void verificar();
}