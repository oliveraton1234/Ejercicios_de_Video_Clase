package PracticaLogin;

public class Main {
    public static void main(String[] args) {
        MainFrame a = new MainFrame();

    }
}