package PracticaColores;

public interface Listener {
    public void spinnerRed();
    public void spinnerGreen();
    public void spinnerBlue();

    public void sliderRed();
    public void sldierGreen();
    public void sliderBlue();
}