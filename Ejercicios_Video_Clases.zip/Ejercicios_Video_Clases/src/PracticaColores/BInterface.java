package PracticaColores;

public interface BInterface {
    public void generar();
}