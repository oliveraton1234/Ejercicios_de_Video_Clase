package SeleccionDeArchivos;

public interface Listener {
    public void abrirArchivo();
    public void guardarArchivo();
    public void seleccionarColor();

}