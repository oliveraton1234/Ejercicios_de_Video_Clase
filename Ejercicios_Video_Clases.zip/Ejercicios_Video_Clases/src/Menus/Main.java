package Menus;

/**
 *
 * @author Admin
 */
public class Main {
    public static void main(String[] args) {
        new MainFrame ();
        
    }
    
}