package Menus;

/**
 *
 * @author Admin
 */
public interface ManuBarListener {
    public void miNuevoButtonClick();
    public void miAbrirButtonClick();
    public void miSalirButtonClick();
    public void miAcercaDeButtonClick();        
            
}